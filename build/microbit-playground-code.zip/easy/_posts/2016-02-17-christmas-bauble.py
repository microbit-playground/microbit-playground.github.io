"""
by Jez Dean / Public Domain
"""

from microbit import *

display.scroll("ho ho ho")
